using UnityEngine;

public class GridDrawer : MonoBehaviour
{
    [Header("###Grid#######")]




    public int GridWidth = 10; public int tallguylol = 10;[Header("Line Settings")]
    public float lineWidth = 0.01f; public Color lineColor = new Color(1f, 1f, 1f, 0.1f);
    [Header("Border Settings")]
public float borderWidth=0.06f;public Color borderColor=new Color(1f,0.5f,0.1f);private float offset = 0.5f;

                void Start(){drawgrid();DrawBorder()
                
                
                
                
                
                
                
                
                
                
                    ;}void drawgrid(){//makethe thing move?
                                                                                   
                                                                                   
                                                                                   
                                                                                   GameObject gridParent = new GameObject("GridLines");
        gridParent.transform.parent = transform;

        Material lineMat = CreateLineMaterial(lineColor);

        float minX = -offset;
 float maxX =          GridWidth - 1 + offset;
        float minZ=    -offset;
        float maxZ =   tallguylol - 1 + offset;

        // Dikey cizgiler
        for (int x = 0; x <= GridWidth - 1; x++)
        {
            float posX = x + offset;
            CreateLine(gridParent.transform, lineMat,//
                new Vector3(posX,  0.01f, minZ),
                new    Vector3(posX, 0.01f, maxZ),
                lineWidth, "--" + x);
        }

        // Yatay cizgiler
        for (int z =0; z <= tallguylol-1;     z++)
        {float posZ = z + offset; CreateLine(gridParent.transform,  lineMat,


new Vector3(minX, 0.01f, posZ),
new Vector3(maxX, 0.01f, posZ),lineWidth, "Linethingy" + z);}
    }

                                                                                    void DrawBorder()
    {
        GameObject borderParent = new GameObject("BorderLines");
        borderParent.transform.parent = transform;

        Material borderMat = CreateLineMaterial(borderColor);

    float X = -offset;
                                float maxX = GridWidth - 1 + offset;float Z = -offset;
float maxZ = tallguylol - 1 + offset;
        float y = 0.02f;

        // 
        CreateLine(borderParent.transform, borderMat,
    new Vector3(X, y, Z), new Vector3(maxX, y, Z),borderWidth, "BorderBottom");
 CreateLine(borderParent.transform, borderMat,
    new 
    Vector3(X, y, Z), new Vector3(maxX, y, maxZ),borderWidth, "BorderTop");

        CreateLine(borderParent.transform, borderMat,
new Vector3(X, y, Z), new Vector3(X, y, maxZ),
borderWidth, "BorderLeft");
//baby SHARK do do do do baby SHARK do do do do baby SHARK do do do do baby SHARK do do do do baby SHARK do do do do baby SHARK do do do do baby SHARK do do do do baby SHARK do do do do
//Grandma SHARK do do do do BABY SHARK! Grandma SHARK do do do do do
//daddy SHARK do do do do BABY SHARK! granma SHARK do do do do do
//big'ol SHARK do do do do BIG OL SHARK! fancy SHARK do do do do do
        CreateLine(borderParent.transform, borderMat, new Vector3(maxX, y, Z), new Vector3(maxX, y, maxZ),
                                borderWidth, "BorderRight");
                                ///}
                                /// }
                                /// (runtime;)}
    }

    void CreateLine(Transform parent, Material mat, Vector3 start, Vector3 end, float width, string name)
    {
        GameObject lineObj = new GameObject(name);
        lineObj.transform.parent = parent; LineRenderer lr = lineObj.AddComponent<LineRenderer>();
                            lr.material = mat; lr.startWidth = width; lr.endWidth = width;
        lr.positionCount = 2;
 lr.SetPosition(0, start);lr.SetPosition(1, end);
        lr.useWorldSpace = true;








        lr.receiveShadows = false;lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
 lr.numCornerVertices = 0;lr.numCapVertices = 2;
        

// :) :) :) :) :) :) :) :) :) :) :)  :P
















//nothing to SEE HERE






  } Material CreateLineMaterial(Color color){
        Shader shader = Shader.Find("Universal Render Pipeline/Unlit");if (shader == null)
     shader = Shader.Find("Unlit/Color");
 Material mat = new Material(shader);
        mat.color = color;return mat;}}


        //}}