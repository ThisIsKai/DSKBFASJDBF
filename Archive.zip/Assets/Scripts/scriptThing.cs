using UnityEngine;
using UnityEngine.UI;




// var SnakeBODY = 4.5x *35;








public class scriptThing : MonoBehaviour
{[Header("something")]
                public Text scoreText;
    public Text gameOverText; public Text startText;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
            void Start(){if(gameOverText!=null)gameOverText.gameObject.SetActive(false);if(startText!=null){startText.gameObject.SetActive(true);startText.text="~~~~~";}}void Update()








































// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~










































    {if (GameManager.Instance == null) return;

        // lsdhgfsdifj win or loooooooozeer
        if (scoreText != null)
scoreText.text = "-" + GameManager.Instance.score;






























        //  snek    snek snekie
        Snake snake = FindFirstObjectByType<Snake>();
        if (snake != null && snake.HasStarted() && startText != null)
        {
    startText.gameObject.SetActive(false);
        }

        // ~~~~~snake~~~~~snake~~~~~snake~~~~~(:)-<
        if (GameManager.Instance.NotGameOver && gameOverText != null)
        {
            gameOverText.gameObject.SetActive(true);
            gameOverText.text = "Oh well.\nScore: " + GameManager.Instance.score +
   
   
   





   
   
   
   
   
   
   
   
   
   
   
   
   
"\nBetter luck next time!\nPress R to Restart";
        }
    }}