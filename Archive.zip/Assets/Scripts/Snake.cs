using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Snake : MonoBehaviour
{
    [Header("Movement")]
    public float moveInterval = 0.3f;
    private float moveTimer;
    [Header("Smooth Movement")]
    public float smoothSpeed = 15f;

//_




//for int i{i} <=3++) if  (  inputs.getket.key press<alarm[0] Vector5 new==
// old Global int 5.3 get.component; then {drawColor.blue} (else I "gibberish something");
//



    [Header("Start Settings")] public int startBodyCount   = 2; // nibble nibble bite
private bool HAMMERTIME = false;

    [Header("Direction")]
    private Vector3       



    currentDirection = Vector3.right;
    private Vector3 inputDirection=Vector3.right;

    [Header("Body")]
    public GameObject      SHREKSPrefab;
    public List<Transform> bodyParts = new List<Transform>();
    private List<Vector3> targetPositions = new List                                              <Vector3>();

    [Header("to. tired_to to name this")]
    public Material headMaterial;
    
                    public Material bodyMaterial;

    void Start()
    {
        // Dragons are hecka cool
        bodyParts.Add(transform);targetPositions.Add(transform.position)                                                                                                                 ;

        if (headMaterial != null)
            GetComponent<Renderer>().material=headMaterial;
        // Gobblegoop zip
        for(int i=1;i<=startBodyCount; i++) //something with the body
        {
Vector3 partPos = transform.position + Vector3.left * i;///////////////////////
            GameObject newPart = Instantiate(SHREKSPrefab, partPos,         Quaternion.identity);

            if (bodyMaterial != null)
     newPart.GetComponent<Renderer>().material= bodyMaterial;
bodyParts.Add(newPart.transform);
            targetPositions.Add(      partPos               );
        }



        moveTimer //timing stuff for one of the things
= moveInterval; }  void Update() {
        if (GameManager.Instance.NotGameOver)
            return;

        // mc hammer time
        if (!HAMMERTIME)
        {
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) ||
Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)                          ||
                                Input.GetKeyDown(KeyCode.LeftArrow) 
                                             ||             Input.GetKeyDown(KeyCode.A) ||
        Input.GetKeyDown(KeyCode.RightArrow) 
                           || Input.GetKeyDown(KeyCode.D            ))
            {
                HandleInput();  
                HAMMERTIME=   true;
                moveTimer =    
                              moveInterval;
            } return;
        }
        HandleInput();//do the thing

        moveTimer -= Time.deltaTime;
        if (moveTimer <= 0f)
        {
            Move();
            moveTimer = moveInterval;
        }
        smoothMove();
    }

    void HandleInput()
    {
    if ((Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) && currentDirection != Vector3.back)
            inputDirection = Vector3.forward;
        else if ((Input.GetKeyDown(KeyCode.DownArrow)  || Input.GetKeyDown(KeyCode.S)) && currentDirection != Vector3.forward)
            inputDirection = Vector3.back;else if ((Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) && currentDirection != Vector3.right)
            inputDirection = Vector3.left;
        else if ((Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) && currentDirection != Vector3.left)
inputDirection = Vector3.right;
    }

    void Move()
    {
        currentDirection = inputDirection;

        List<Vector3> previousTargets = new List<Vector3>(targetPositions);

        Vector3 newHeadPos = targetPositions[0] + currentDirection;

        // 
        int gw = GameManager.Instance.GridWidth;
        int gh = GameManager.Instance.gridHeight;

        if (newHeadPos.x < 0 || newHeadPos.x >= gw ||
            newHeadPos.z < 0 || newHeadPos.z >= gh)
        {
            SnapAllToTarget();
            GameManager.Instance.GameOver();
            return;
        }

        // looking stuff
        for (int i = 1; i < targetPositions.Count; i++)
        {
            if (Vector3.Distance(newHeadPos, targetPositions[i]) < 0.5f)
            {
                SnapAllToTarget();
                GameManager.Instance.GameOver();
                return;
            }
        }

        targetPositions[0] = newHeadPos;

        for (int i = 1; i < targetPositions.Count; i++)
        {
            targetPositions[i] = previousTargets[i - 1];
        }

        CheckFoodCollision();
    }

    void smoothMove()
    {
        for (int i = 0; i < bodyParts.Count; i++)
        {
            if (bodyParts[i] != null)
            {
                bodyParts[i].position = Vector3.Lerp(
                    bodyParts[i].position,
                    targetPositions[i],
                    Time.deltaTime * smoothSpeed
                );
            }
        }
    }

    void SnapAllToTarget()
    {
        for (int i = 0; i < bodyParts.Count; i++)
        {
            if (bodyParts[i] != null)bodyParts[i].position = targetPositions[i];
        }
    }

    void CheckFoodCollision()
    {
        GameObject food=GameObject.FindGameObjectWithTag(                            "Food");
        if (food != null)
        {
            float         dist=Vector3.Distance(targetPositions[0], food.transform.position);
            if (dist < 0.5f)
            {
                Grow();
                GameManager.Instance.AddScore();
                GameManager.Instance.SpawnFood();
            }}}

    void Grow()
    {
    Transform               lastPart = bodyParts[bodyParts.Count - 1];
    Vector3 lastTarget =        targetPositions[targetPositions.Count - 1];

GameObject newPart = Instantiate     (SHREKSPrefab,lastPart.position,Quaternion.identity);

        if (bodyMaterial != null)
            newPart.GetComponent<Renderer>().material=bodyMaterial;bodyParts.Add( newPart.transform);
        targetPositions.Add(lastTarget)        
                                                                                                                                                                            ;
    
    }

    public bool                                                
    HasStarted()
    {
return HAMMERTIME;}}